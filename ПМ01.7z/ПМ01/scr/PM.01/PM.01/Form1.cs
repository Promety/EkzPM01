﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PM._01 {
	public partial class Form1 : Form 
	{
		private bool flag = false;
		bool select;

		
		public Form1() {
			InitializeComponent();
		}
		void FUNC1()

			
			{
			double x = double.Parse(numericUpDown1.Text);
			double y = double.Parse(numericUpDown2.Text);
		    double r1 = 1;
			double r2 = 16;
			double r3 = 49;
			if (x == r1|| x * x + y * y == r1)
                {
                    MessageBox.Show("На границе");
				toolStripStatusLabel1.Text = "Находится на границе функции";
                }
			 else if (x * x + y * y > r1 || x * x + y * y < r3 )
                {
                   MessageBox.Show("Внутри");
				toolStripStatusLabel1.Text = "Находится внутри функций";
                }
			else if (x * x + y * y > r2 || x * x + y * y < r3 )
                {
                   MessageBox.Show("Вне");
				toolStripStatusLabel1.Text = "Находится вне функций";
                }
				else if(x == r2 || x * x + y * y == r2 )
                {
                    MessageBox.Show("На границе");
				toolStripStatusLabel1.Text = "Находится на границе функции";
                }
				
				else if(x == r3 || x * x - y * y == r3 )
                {
                    MessageBox.Show("На границе");
				toolStripStatusLabel1.Text = "Находится на границу функции";
				}
                else{
				MessageBox.Show ("ВНЕ");
				toolStripStatusLabel1.Text = "Находится вне функций";
				}
			}
		 
		void FUNC2()
			{
			double x = double.Parse(numericUpDown1.Text);
			double y = double.Parse(numericUpDown2.Text);

			}
			private void открытьToolStripMenuItem_Click(object sender, EventArgs e) 
			{
				OpenFileDialog open_dialog1 = new OpenFileDialog();
				webBrowser1.AllowWebBrowserDrop = false;
				 open_dialog1.Filter = "TextFiles(*.html)|*.html|AllFiles(*.*)|*.*";
					open_dialog1.ShowDialog();
				if (!flag)
                {
                    this.Height += 100;
                    flag = true;
                }
                string[] repSplit = open_dialog1.FileName.Split('\\');
                string curFile = repSplit[repSplit.Length - 1];
                if (curFile == "1.html")
                {
                    webBrowser1.Navigate(open_dialog1.FileName);
                    select = true;
                }
                else if (curFile == "2.html")
                {
                    webBrowser1.Navigate(open_dialog1.FileName);
                    select = false;
                }
                else
                {
                    MessageBox.Show($"Нет решения для {curFile}. Попробуйте выбрать файлы 1.html и 2.html");
                }
			}
		

		private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e) {
		MessageBox.Show ("Написал: Крайнов Дмитрий Николаевич, студент группы ПКсп-120","О программе");
		}

		private void button1_Click(object sender, EventArgs e) {
				FUNC1();
		}

		private void toolStripStatusLabel1_Click(object sender, EventArgs e) {

		}
	}
}
